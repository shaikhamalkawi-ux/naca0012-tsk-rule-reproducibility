# 57 H3 Airfoil — R19 Candidate: Leave-One-Geometry-Out External Transfer

Status: RESEARCH EXTENSION ONLY. R18 remains the active manuscript until this extension is admitted.

## Scientific purpose
Close the main R18 external-validity gap by training on all Southampton geometries except one and testing on the completely unseen held-out geometry. No held-out geometry rows, targets, or spectra enter TSK or Extra-Trees tuning.

## Data
- University of Southampton public archive, DOI 10.5258/SOTON/398169.
- 343 experimental rows, 38 spectra, 7 aerofoil geometries.
- Response is the published normalized quantity SPL/SPL_expt,max, NOT absolute dB. This means the experiment is an unseen-geometry normalized-spectrum-shape transfer test, not absolute-noise deployment validation.

## Inputs
[log10 frequency, angle of attack, trip flag, chord, velocity]. Geometry ID is never supplied as an input.

## Design
- Outer unit: entire aerofoil geometry (7 leave-one-geometry-out folds).
- TSK inner tuning: grouped by spectra, 4 folds, R in {2,4,6}, h in {0.75,1,1.5}, lambda in {1e-6,1e-4,1e-2,1,100}, five FCM starts.
- Extra Trees control: 400 trees, nested spectral-group selection of min leaf in {1,3,5}.
- Primary errors: equal-geometry and equal-spectrum RMSE on normalized response.
- Statement audit: local log-frequency slopes in the pooled TSK model, with the inherited scale-matched pointwise budget and 1% ridge-objective budget.

## Locked candidate results
- TSK equal-geometry RMSE: 0.059396103.
- Extra Trees equal-geometry RMSE: 0.051799561.
- TSK equal-spectrum RMSE: 0.056367931.
- Extra Trees equal-spectrum RMSE: 0.044901649.
- Geometry-specific TSK RMSE range: 0.045010–0.093320.
- Geometry-specific Extra Trees RMSE range: 0.021781–0.091777.
- Pooled TSK frequency-slope audit: 18/18 protected from zero, 0 strict reversals, 0 unresolved.
- Independent stored-state prediction replay maximum absolute discrepancy: 2.22e-16.

## Important negative evidence
- NACA0012 and DU96-180 are extreme fuzzy-support extrapolation cases in the pooled TSK fit: median best-rule log firing is about -55.33 and -17.55, respectively. Normalized firing weights therefore mask poor absolute antecedent coverage. This is scientifically useful evidence for reporting absolute coverage alongside normalized rule weights.
- The normalized target prevents claiming absolute cross-geometry acoustic prediction.

## Admission decision
This extension is scientifically useful and directly addresses the R18 'no unseen geometry' limitation, but only for normalized spectrum shape. It should enter the manuscript only with that exact scope. A stronger absolute-dB external test should supersede it if the 4TU NACA 63_3-018 acoustic archive can be acquired and parsed without target-derived normalization.
